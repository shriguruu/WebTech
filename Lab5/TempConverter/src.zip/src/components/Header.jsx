function Header(){
    return(
    <h2>Temperature Converter</h2>
    )
}
export default Header;