// Content Component

function Content({textContent}){
    return(
        <p className="content">{textContent}</p>
    )
}

export default Content;