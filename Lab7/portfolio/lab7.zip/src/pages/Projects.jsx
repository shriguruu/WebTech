import Header from "../components/Header";
import SubHeader from "../components/SubHeader";
import Content from "../components/Content";

function Projects()
{
    return(
        <div className="page-container">
            <Header textContent={"Projects"}></Header>
            
            <SubHeader textContent={"Conference Booking System"}/>

            <br></br>

            <Content textContent={"Technologies: Python, Django, HTML, CSS, MySQL"}/>
            <Content textContent={"- Developed a full stack web application using Django enabling users to manage and book conferences."} />
            <Content textContent={"- Implemented secure user authentication, registration and role-based access."} />
            <Content textContent={"- Utilized Django ORM for efficient database operations."} />

        </div>
    )
}

export default Projects;