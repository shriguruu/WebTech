import Header from "../components/Header.jsx";
import Content from "../components/Content.jsx";


function Home() {
  return (
    <div className="page-container">
     <Header textContent={"Ni"}></Header>
     <Content textContent={"Third year undergraduate student pursuing a Bachelor of Technology in Artificial Intelligence and Data Science with a keen interest in full stack web development. Proficient in Java with a growing emphasis on full stack web development. Enjoy building responsive and intuitive web applications and continuously learning new technologies. Comfortable working in collaborative team settings with a strong focus on writing clean code. Eager to explore how ML can enhance web-based solutions."}></Content>
    </div>
  );
}

export default Home;