import {Routes, Route, BrowserRouter} from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Education from './pages/Education';
import Skills from './pages/Skills';
import Projects from './pages/Projects';
import './App.css'

function App() {

  return (
      <>
        <BrowserRouter>
        <Navbar />
        <div className="content">
          <Routes>
            <Route path="/" Component={Home} />
            <Route path="/education" Component={Education} />
            <Route path="/skills" Component={Skills} />
            <Route path="/projects" Component={Projects} />
          </Routes>
        </div>
        </BrowserRouter>
      </> 
  )
}

export default App;
